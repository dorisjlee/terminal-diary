import sys
from .terminal_diary import main
main()
